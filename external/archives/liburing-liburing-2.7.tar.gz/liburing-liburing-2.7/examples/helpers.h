/* SPDX-License-Identifier: MIT */
#ifndef LIBURING_EX_HELPERS_H
#define LIBURING_EX_HELPERS_H

int setup_listening_socket(int port, int ipv6);

#endif
